import UserForm from "./components/UserForm/UserForm";

export default function App() {
  return <UserForm />;
}
